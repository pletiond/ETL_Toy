from ETL_Toy.cli.cli import main

main()
